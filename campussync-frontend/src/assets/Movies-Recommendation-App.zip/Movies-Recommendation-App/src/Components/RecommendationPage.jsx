import React from 'react'

function RecommendationPage() {
  return (
    <div className='flex justify-center'>
      <h1 className='font-serif font-bold text-4xl m-11'>Recommendation Page</h1>
    </div>
  )
}

export default RecommendationPage


